package net.mcreator.mymodmaybeig.fluid;

import org.apache.logging.log4j.core.util.Source;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.mymodmaybeig.init.MyModMaybeIgModItems;
import net.mcreator.mymodmaybeig.init.MyModMaybeIgModFluids;
import net.mcreator.mymodmaybeig.init.MyModMaybeIgModFluidTypes;
import net.mcreator.mymodmaybeig.init.MyModMaybeIgModBlocks;

public abstract class SunwaterFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> MyModMaybeIgModFluidTypes.SUNWATER_TYPE.get(), () -> MyModMaybeIgModFluids.SUNWATER.get(), () -> MyModMaybeIgModFluids.FLOWING_SUNWATER.get())
			.explosionResistance(100f).bucket(() -> MyModMaybeIgModItems.SUNWATER_BUCKET.get()).block(() -> (LiquidBlock) MyModMaybeIgModBlocks.SUNWATER.get());

	private SunwaterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends SunwaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends SunwaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}