/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymodmaybeig.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.capability.wrappers.FluidBucketWrapper;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.mymodmaybeig.item.*;
import net.mcreator.mymodmaybeig.MyModMaybeIgMod;

import java.util.function.Function;

public class MyModMaybeIgModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(MyModMaybeIgMod.MODID);
	public static final DeferredItem<Item> MOONSTONEORE;
	public static final DeferredItem<Item> RAWMOONSTONE;
	public static final DeferredItem<Item> RAWSUNSTONE;
	public static final DeferredItem<Item> SUNSTONEINGOT;
	public static final DeferredItem<Item> MOONSTONEUPGRADETEMPLATE;
	public static final DeferredItem<Item> SUNSTONEUPGRADETEMPLATE;
	public static final DeferredItem<Item> MOONSTONE;
	public static final DeferredItem<Item> MOONSTONEARMOR_HELMET;
	public static final DeferredItem<Item> MOONSTONEARMOR_CHESTPLATE;
	public static final DeferredItem<Item> MOONSTONEARMOR_LEGGINGS;
	public static final DeferredItem<Item> MOONSTONEARMOR_BOOTS;
	public static final DeferredItem<Item> MOONSTONEPICKAXE;
	public static final DeferredItem<Item> MOONSTONEAXE;
	public static final DeferredItem<Item> MOONSTONESHOVEL;
	public static final DeferredItem<Item> MOONSTONESWORD;
	public static final DeferredItem<Item> MOONSTONEHOE;
	public static final DeferredItem<Item> SUNSTONEPICKAXE;
	public static final DeferredItem<Item> SUNSTONEAXE;
	public static final DeferredItem<Item> SUNSTONESHOVEL;
	public static final DeferredItem<Item> SUNSTONEHOE;
	public static final DeferredItem<Item> SUNSTONESWORD;
	public static final DeferredItem<Item> SUNSTONEARMOR_HELMET;
	public static final DeferredItem<Item> SUNSTONEARMOR_CHESTPLATE;
	public static final DeferredItem<Item> SUNSTONEARMOR_LEGGINGS;
	public static final DeferredItem<Item> SUNSTONEARMOR_BOOTS;
	public static final DeferredItem<Item> MOONSTONEBLOCK;
	public static final DeferredItem<Item> SUNBLOCK;
	public static final DeferredItem<Item> SUNWATER_BUCKET;
	public static final DeferredItem<Item> SUNDIMENSION;
	public static final DeferredItem<Item> SUNSTONEORE;
	static {
		MOONSTONEORE = block(MyModMaybeIgModBlocks.MOONSTONEORE);
		RAWMOONSTONE = register("rawmoonstone", RawmoonstoneItem::new);
		RAWSUNSTONE = register("rawsunstone", RawsunstoneItem::new);
		SUNSTONEINGOT = register("sunstoneingot", SunstoneingotItem::new);
		MOONSTONEUPGRADETEMPLATE = register("moonstoneupgradetemplate", MoonstoneupgradetemplateItem::new);
		SUNSTONEUPGRADETEMPLATE = register("sunstoneupgradetemplate", SunstoneupgradetemplateItem::new);
		MOONSTONE = register("moonstone", MoonstoneItem::new);
		MOONSTONEARMOR_HELMET = register("moonstonearmor_helmet", MoonstonearmorItem.Helmet::new);
		MOONSTONEARMOR_CHESTPLATE = register("moonstonearmor_chestplate", MoonstonearmorItem.Chestplate::new);
		MOONSTONEARMOR_LEGGINGS = register("moonstonearmor_leggings", MoonstonearmorItem.Leggings::new);
		MOONSTONEARMOR_BOOTS = register("moonstonearmor_boots", MoonstonearmorItem.Boots::new);
		MOONSTONEPICKAXE = register("moonstonepickaxe", MoonstonepickaxeItem::new);
		MOONSTONEAXE = register("moonstoneaxe", MoonstoneaxeItem::new);
		MOONSTONESHOVEL = register("moonstoneshovel", MoonstoneshovelItem::new);
		MOONSTONESWORD = register("moonstonesword", MoonstoneswordItem::new);
		MOONSTONEHOE = register("moonstonehoe", MoonstonehoeItem::new);
		SUNSTONEPICKAXE = register("sunstonepickaxe", SunstonepickaxeItem::new);
		SUNSTONEAXE = register("sunstoneaxe", SunstoneaxeItem::new);
		SUNSTONESHOVEL = register("sunstoneshovel", SunstoneshovelItem::new);
		SUNSTONEHOE = register("sunstonehoe", SunstonehoeItem::new);
		SUNSTONESWORD = register("sunstonesword", SunstoneswordItem::new);
		SUNSTONEARMOR_HELMET = register("sunstonearmor_helmet", SunstonearmorItem.Helmet::new);
		SUNSTONEARMOR_CHESTPLATE = register("sunstonearmor_chestplate", SunstonearmorItem.Chestplate::new);
		SUNSTONEARMOR_LEGGINGS = register("sunstonearmor_leggings", SunstonearmorItem.Leggings::new);
		SUNSTONEARMOR_BOOTS = register("sunstonearmor_boots", SunstonearmorItem.Boots::new);
		MOONSTONEBLOCK = block(MyModMaybeIgModBlocks.MOONSTONEBLOCK);
		SUNBLOCK = block(MyModMaybeIgModBlocks.SUNBLOCK, new Item.Properties().fireResistant());
		SUNWATER_BUCKET = register("sunwater_bucket", SunwaterItem::new);
		SUNDIMENSION = register("sundimension", SundimensionItem::new);
		SUNSTONEORE = block(MyModMaybeIgModBlocks.SUNSTONEORE, new Item.Properties().fireResistant());
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), SUNWATER_BUCKET.get());
	}
}