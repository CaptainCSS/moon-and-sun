/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymodmaybeig.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.mymodmaybeig.fluid.types.SunwaterFluidType;
import net.mcreator.mymodmaybeig.MyModMaybeIgMod;

public class MyModMaybeIgModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, MyModMaybeIgMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> SUNWATER_TYPE = REGISTRY.register("sunwater", () -> new SunwaterFluidType());
}