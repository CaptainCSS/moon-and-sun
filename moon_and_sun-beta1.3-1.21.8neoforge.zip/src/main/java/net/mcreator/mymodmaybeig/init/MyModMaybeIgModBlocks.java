/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymodmaybeig.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.mymodmaybeig.block.*;
import net.mcreator.mymodmaybeig.MyModMaybeIgMod;

import java.util.function.Function;

public class MyModMaybeIgModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(MyModMaybeIgMod.MODID);
	public static final DeferredBlock<Block> MOONSTONEORE;
	public static final DeferredBlock<Block> MOONSTONEBLOCK;
	public static final DeferredBlock<Block> SUNBLOCK;
	public static final DeferredBlock<Block> SUNWATER;
	public static final DeferredBlock<Block> SUNDIMENSION_PORTAL;
	public static final DeferredBlock<Block> SUNSTONEORE;
	static {
		MOONSTONEORE = register("moonstoneore", RawmoonstoneoreBlock::new);
		MOONSTONEBLOCK = register("moonstoneblock", MoonstoneblockBlock::new);
		SUNBLOCK = register("sunblock", SunblockBlock::new);
		SUNWATER = register("sunwater", SunwaterBlock::new);
		SUNDIMENSION_PORTAL = register("sundimension_portal", SundimensionPortalBlock::new);
		SUNSTONEORE = register("sunstoneore", SunstoneoreBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}