/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymodmaybeig.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.mymodmaybeig.MyModMaybeIgMod;

@EventBusSubscriber
public class MyModMaybeIgModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MyModMaybeIgMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MOON = REGISTRY.register("moon",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.my_mod_maybe_ig.moon")).icon(() -> new ItemStack(MyModMaybeIgModItems.MOONSTONE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(MyModMaybeIgModBlocks.MOONSTONEORE.get().asItem());
				tabData.accept(MyModMaybeIgModItems.RAWMOONSTONE.get());
				tabData.accept(MyModMaybeIgModItems.MOONSTONEUPGRADETEMPLATE.get());
				tabData.accept(MyModMaybeIgModItems.MOONSTONE.get());
				tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_HELMET.get());
				tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_CHESTPLATE.get());
				tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_LEGGINGS.get());
				tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_BOOTS.get());
				tabData.accept(MyModMaybeIgModItems.MOONSTONEPICKAXE.get());
				tabData.accept(MyModMaybeIgModItems.MOONSTONEAXE.get());
				tabData.accept(MyModMaybeIgModItems.MOONSTONESHOVEL.get());
				tabData.accept(MyModMaybeIgModItems.MOONSTONESWORD.get());
				tabData.accept(MyModMaybeIgModItems.MOONSTONEHOE.get());
				tabData.accept(MyModMaybeIgModBlocks.MOONSTONEBLOCK.get().asItem());
			}).withSearchBar().build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> SUN = REGISTRY.register("sun",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.my_mod_maybe_ig.sun")).icon(() -> new ItemStack(MyModMaybeIgModItems.SUNSTONEINGOT.get())).displayItems((parameters, tabData) -> {
				tabData.accept(MyModMaybeIgModItems.RAWSUNSTONE.get());
				tabData.accept(MyModMaybeIgModItems.SUNSTONEINGOT.get());
				tabData.accept(MyModMaybeIgModItems.SUNSTONEUPGRADETEMPLATE.get());
				tabData.accept(MyModMaybeIgModItems.SUNSTONEPICKAXE.get());
				tabData.accept(MyModMaybeIgModItems.SUNSTONEAXE.get());
				tabData.accept(MyModMaybeIgModItems.SUNSTONESHOVEL.get());
				tabData.accept(MyModMaybeIgModItems.SUNSTONEHOE.get());
				tabData.accept(MyModMaybeIgModItems.SUNSTONESWORD.get());
				tabData.accept(MyModMaybeIgModBlocks.SUNBLOCK.get().asItem());
				tabData.accept(MyModMaybeIgModItems.SUNWATER_BUCKET.get());
				tabData.accept(MyModMaybeIgModBlocks.SUNSTONEORE.get().asItem());
			}).withSearchBar().withTabsBefore(MOON.getId()).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_HELMET.get());
			tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_CHESTPLATE.get());
			tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_LEGGINGS.get());
			tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_BOOTS.get());
			tabData.accept(MyModMaybeIgModItems.SUNSTONEARMOR_HELMET.get());
			tabData.accept(MyModMaybeIgModItems.SUNSTONEARMOR_CHESTPLATE.get());
			tabData.accept(MyModMaybeIgModItems.SUNSTONEARMOR_LEGGINGS.get());
			tabData.accept(MyModMaybeIgModItems.SUNSTONEARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(MyModMaybeIgModItems.MOONSTONEPICKAXE.get());
			tabData.accept(MyModMaybeIgModItems.MOONSTONEAXE.get());
			tabData.accept(MyModMaybeIgModItems.MOONSTONESHOVEL.get());
			tabData.accept(MyModMaybeIgModItems.MOONSTONESWORD.get());
			tabData.accept(MyModMaybeIgModItems.MOONSTONEHOE.get());
			tabData.accept(MyModMaybeIgModItems.SUNSTONEPICKAXE.get());
			tabData.accept(MyModMaybeIgModItems.SUNSTONEAXE.get());
			tabData.accept(MyModMaybeIgModItems.SUNSTONESHOVEL.get());
			tabData.accept(MyModMaybeIgModItems.SUNSTONEHOE.get());
			tabData.accept(MyModMaybeIgModItems.SUNSTONESWORD.get());
			tabData.accept(MyModMaybeIgModItems.SUNDIMENSION.get());
		}
	}
}