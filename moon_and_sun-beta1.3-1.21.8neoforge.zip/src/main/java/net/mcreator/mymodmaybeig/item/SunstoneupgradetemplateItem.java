package net.mcreator.mymodmaybeig.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class SunstoneupgradetemplateItem extends Item {
	public SunstoneupgradetemplateItem(Item.Properties properties) {
		super(properties);
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}