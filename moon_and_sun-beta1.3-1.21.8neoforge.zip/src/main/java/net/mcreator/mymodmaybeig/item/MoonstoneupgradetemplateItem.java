package net.mcreator.mymodmaybeig.item;

import net.minecraft.world.item.Item;

public class MoonstoneupgradetemplateItem extends Item {
	public MoonstoneupgradetemplateItem(Item.Properties properties) {
		super(properties);
	}
}