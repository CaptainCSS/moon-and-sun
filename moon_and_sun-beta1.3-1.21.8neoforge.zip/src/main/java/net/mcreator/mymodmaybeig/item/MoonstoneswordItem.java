package net.mcreator.mymodmaybeig.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class MoonstoneswordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 6093, 27f, 0, 45, TagKey.create(Registries.ITEM, ResourceLocation.parse("my_mod_maybe_ig:moonstonesword_repair_items")));

	public MoonstoneswordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 23f, 0.8f).fireResistant());
	}
}