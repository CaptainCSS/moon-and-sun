package net.mcreator.mymodmaybeig.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class RawsunstoneItem extends Item {
	public RawsunstoneItem(Item.Properties properties) {
		super(properties);
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}