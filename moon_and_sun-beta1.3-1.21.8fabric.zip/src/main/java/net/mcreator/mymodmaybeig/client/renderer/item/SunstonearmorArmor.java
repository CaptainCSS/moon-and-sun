package net.mcreator.mymodmaybeig.client.renderer.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.resources.model.EquipmentClientInfo;

import net.mcreator.mymodmaybeig.init.MyModMaybeIgModItems;
import net.mcreator.mymodmaybeig.init.MyModMaybeIgModArmorModels;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class SunstonearmorArmor {
	public static void clientLoad() {
		MyModMaybeIgModArmorModels.ARMOR_MODELS.put(MyModMaybeIgModItems.SUNSTONEARMOR_HELMET, new MyModMaybeIgModArmorModels.ArmorModel() {
			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation _default) {
				return ResourceLocation.parse("my_mod_maybe_ig:textures/entities/sunstone_layer_1.png");
			}
		});
		MyModMaybeIgModArmorModels.ARMOR_MODELS.put(MyModMaybeIgModItems.SUNSTONEARMOR_CHESTPLATE, new MyModMaybeIgModArmorModels.ArmorModel() {
			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation _default) {
				return ResourceLocation.parse("my_mod_maybe_ig:textures/entities/sunstone_layer_1.png");
			}
		});
		MyModMaybeIgModArmorModels.ARMOR_MODELS.put(MyModMaybeIgModItems.SUNSTONEARMOR_LEGGINGS, new MyModMaybeIgModArmorModels.ArmorModel() {
			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation _default) {
				return ResourceLocation.parse("my_mod_maybe_ig:textures/entities/sunstone_layer_2.png");
			}
		});
		MyModMaybeIgModArmorModels.ARMOR_MODELS.put(MyModMaybeIgModItems.SUNSTONEARMOR_BOOTS, new MyModMaybeIgModArmorModels.ArmorModel() {
			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation _default) {
				return ResourceLocation.parse("my_mod_maybe_ig:textures/entities/sunstone_layer_1.png");
			}
		});
	}
}