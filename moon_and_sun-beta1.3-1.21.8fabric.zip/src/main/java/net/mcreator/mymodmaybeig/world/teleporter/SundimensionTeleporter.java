package net.mcreator.mymodmaybeig.world.teleporter;

import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.NetherPortalBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.entity.ai.village.poi.PoiType;
import net.minecraft.world.entity.ai.village.poi.PoiRecord;
import net.minecraft.world.entity.ai.village.poi.PoiManager;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Vec3i;
import net.minecraft.core.Holder;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.BlockUtil;

import net.mcreator.mymodmaybeig.init.MyModMaybeIgModBlocks;

import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;

import java.util.Optional;
import java.util.Comparator;

import com.google.common.collect.ImmutableSet;

public class SundimensionTeleporter {
	public static Holder<PoiType> poi = null;

	public static void registerPointOfInterest() {
		PoiType poiType = PointOfInterestHelper.register(ResourceLocation.parse("my_mod_maybe_ig:sundimension_portal"), 0, 1, ImmutableSet.copyOf(MyModMaybeIgModBlocks.SUNDIMENSION_PORTAL.getStateDefinition().getPossibleStates()));
		poi = BuiltInRegistries.POINT_OF_INTEREST_TYPE.wrapAsHolder(poiType);
	}

	private final ServerLevel level;

	public SundimensionTeleporter(ServerLevel level) {
		this.level = level;
	}

	public Optional<BlockPos> findClosestPortalPosition(BlockPos blockPos3, boolean bl, WorldBorder worldBorder) {
		PoiManager poiManager = this.level.getPoiManager();
		int i = bl ? 16 : 128;
		poiManager.ensureLoadedAndValid(this.level, blockPos3, i);
		return poiManager.getInSquare(holder -> holder.is(poi.unwrapKey().get()), blockPos3, i, PoiManager.Occupancy.ANY).map(PoiRecord::getPos).filter(worldBorder::isWithinBounds)
				.filter(blockPos -> this.level.getBlockState((BlockPos) blockPos).hasProperty(BlockStateProperties.HORIZONTAL_AXIS)).min(Comparator.<BlockPos>comparingDouble(blockPos2 -> blockPos2.distSqr(blockPos3)).thenComparingInt(Vec3i::getY));
	}

	public Optional<BlockUtil.FoundRectangle> createPortal(BlockPos blockPos, Direction.Axis axis) {
		int n;
		int m;
		int l;
		Direction direction = Direction.get(Direction.AxisDirection.POSITIVE, axis);
		double d = -1.0;
		BlockPos blockPos2 = null;
		double e = -1.0;
		BlockPos blockPos3 = null;
		WorldBorder worldBorder = this.level.getWorldBorder();
		int i = Math.min(this.level.getMaxY(), this.level.getMinY() + this.level.getLogicalHeight() - 1);
		boolean j = true;
		BlockPos.MutableBlockPos mutableBlockPos = blockPos.mutable();
		for (BlockPos.MutableBlockPos mutableBlockPos2 : BlockPos.spiralAround(blockPos, 16, Direction.EAST, Direction.SOUTH)) {
			int k = Math.min(i, this.level.getHeight(Heightmap.Types.MOTION_BLOCKING, mutableBlockPos2.getX(), mutableBlockPos2.getZ()));
			if (!worldBorder.isWithinBounds(mutableBlockPos2) || !worldBorder.isWithinBounds(mutableBlockPos2.move(direction, 1)))
				continue;
			mutableBlockPos2.move(direction.getOpposite(), 1);
			for (l = k; l >= this.level.getMinY(); --l) {
				mutableBlockPos2.setY(l);
				if (!this.canPortalReplaceBlock(mutableBlockPos2))
					continue;
				m = l;
				while (l > this.level.getMinY() && this.canPortalReplaceBlock(mutableBlockPos2.move(Direction.DOWN))) {
					--l;
				}
				if (l + 4 > i || (n = m - l) > 0 && n < 3)
					continue;
				mutableBlockPos2.setY(l);
				if (!this.canHostFrame(mutableBlockPos2, mutableBlockPos, direction, 0))
					continue;
				double f = blockPos.distSqr(mutableBlockPos2);
				if (this.canHostFrame(mutableBlockPos2, mutableBlockPos, direction, -1) && this.canHostFrame(mutableBlockPos2, mutableBlockPos, direction, 1) && (d == -1.0 || d > f)) {
					d = f;
					blockPos2 = mutableBlockPos2.immutable();
				}
				if (d != -1.0 || e != -1.0 && !(e > f))
					continue;
				e = f;
				blockPos3 = mutableBlockPos2.immutable();
			}
		}
		if (d == -1.0 && e != -1.0) {
			blockPos2 = blockPos3;
			d = e;
		}
		if (d == -1.0) {
			int p = i - 9;
			int o = Math.max(this.level.getMinY() - -1, 70);
			if (p < o) {
				return Optional.empty();
			}
			blockPos2 = new BlockPos(blockPos.getX() - direction.getStepX() * 1, Mth.clamp(blockPos.getY(), o, p), blockPos.getZ() - direction.getStepZ() * 1).immutable();
			blockPos2 = worldBorder.clampToBounds(blockPos2);
			Direction direction2 = direction.getClockWise();
			for (l = -1; l < 2; ++l) {
				for (m = 0; m < 2; ++m) {
					for (n = -1; n < 3; ++n) {
						BlockState blockState = n < 0 ? MyModMaybeIgModBlocks.MOONSTONEBLOCK.defaultBlockState() : Blocks.AIR.defaultBlockState();
						mutableBlockPos.setWithOffset(blockPos2, m * direction.getStepX() + l * direction2.getStepX(), n, m * direction.getStepZ() + l * direction2.getStepZ());
						this.level.setBlockAndUpdate(mutableBlockPos, blockState);
					}
				}
			}
		}
		for (int o = -1; o < 3; ++o) {
			for (int p = -1; p < 4; ++p) {
				if (o != -1 && o != 2 && p != -1 && p != 3)
					continue;
				mutableBlockPos.setWithOffset(blockPos2, o * direction.getStepX(), p, o * direction.getStepZ());
				this.level.setBlock(mutableBlockPos, MyModMaybeIgModBlocks.MOONSTONEBLOCK.defaultBlockState(), 3);
			}
		}
		BlockState blockState2 = (BlockState) MyModMaybeIgModBlocks.SUNDIMENSION_PORTAL.defaultBlockState().setValue(NetherPortalBlock.AXIS, axis);
		for (int p = 0; p < 2; ++p) {
			for (int k = 0; k < 3; ++k) {
				mutableBlockPos.setWithOffset(blockPos2, p * direction.getStepX(), k, p * direction.getStepZ());
				this.level.setBlock(mutableBlockPos, blockState2, 18);
			}
		}
		return Optional.of(new BlockUtil.FoundRectangle(blockPos2.immutable(), 2, 3));
	}

	private boolean canHostFrame(BlockPos blockPos, BlockPos.MutableBlockPos mutableBlockPos, Direction direction, int i) {
		Direction direction2 = direction.getClockWise();
		for (int j = -1; j < 3; ++j) {
			for (int k = -1; k < 4; ++k) {
				mutableBlockPos.setWithOffset(blockPos, direction.getStepX() * j + direction2.getStepX() * i, k, direction.getStepZ() * j + direction2.getStepZ() * i);
				if (k < 0 && !this.level.getBlockState(mutableBlockPos).isSolid()) {
					return false;
				}
				if (k < 0 || this.canPortalReplaceBlock(mutableBlockPos))
					continue;
				return false;
			}
		}
		return true;
	}

	private boolean canPortalReplaceBlock(BlockPos.MutableBlockPos pos) {
		BlockState blockstate = this.level.getBlockState(pos);
		return blockstate.canBeReplaced() && blockstate.getFluidState().isEmpty();
	}
}