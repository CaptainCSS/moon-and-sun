package net.mcreator.mymodmaybeig.world.dimension;

import net.minecraft.world.phys.Vec3;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.DimensionSpecialEffects;

import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;

public class SundimensionDimension {
	public static void load() {
		DimensionSpecialEffects customEffect = new DimensionSpecialEffects(DimensionSpecialEffects.SkyType.NONE, false, false) {
			@Override
			public Vec3 getBrightnessDependentFogColor(Vec3 color, float sunHeight) {
				return new Vec3(1, 1, 0);
			}

			@Override
			public boolean isFoggyAt(int x, int y) {
				return true;
			}
		};
		DimensionRenderingRegistry.registerDimensionEffects(ResourceLocation.parse("my_mod_maybe_ig:sundimension"), customEffect);
	}
}