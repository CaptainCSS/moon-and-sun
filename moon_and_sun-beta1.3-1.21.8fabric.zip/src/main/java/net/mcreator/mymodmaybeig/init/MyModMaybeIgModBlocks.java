/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymodmaybeig.init;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.mymodmaybeig.block.*;
import net.mcreator.mymodmaybeig.MyModMaybeIgMod;

import java.util.function.Function;

public class MyModMaybeIgModBlocks {
	public static Block MOONSTONEORE;
	public static Block MOONSTONEBLOCK;
	public static Block SUNBLOCK;
	public static Block SUNWATER;
	public static Block SUNDIMENSION_PORTAL;
	public static Block SUNSTONEORE;

	public static void load() {
		MOONSTONEORE = register("moonstoneore", RawmoonstoneoreBlock::new);
		MOONSTONEBLOCK = register("moonstoneblock", MoonstoneblockBlock::new);
		SUNBLOCK = register("sunblock", SunblockBlock::new);
		SUNWATER = register("sunwater", SunwaterBlock::new);
		SUNDIMENSION_PORTAL = register("sundimension_portal", SundimensionPortalBlock::new);
		SUNSTONEORE = register("sunstoneore", SunstoneoreBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> B register(String name, Function<BlockBehaviour.Properties, B> supplier) {
		return (B) Blocks.register(ResourceKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath(MyModMaybeIgMod.MODID, name)), (Function<BlockBehaviour.Properties, Block>) supplier, BlockBehaviour.Properties.of());
	}
}