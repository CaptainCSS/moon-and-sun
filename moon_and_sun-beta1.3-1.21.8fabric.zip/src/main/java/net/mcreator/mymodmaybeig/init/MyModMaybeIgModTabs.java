/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymodmaybeig.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.mymodmaybeig.MyModMaybeIgMod;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

public class MyModMaybeIgModTabs {
	public static ResourceKey<CreativeModeTab> TAB_MOON = ResourceKey.create(Registries.CREATIVE_MODE_TAB, ResourceLocation.fromNamespaceAndPath(MyModMaybeIgMod.MODID, "moon"));
	public static ResourceKey<CreativeModeTab> TAB_SUN = ResourceKey.create(Registries.CREATIVE_MODE_TAB, ResourceLocation.fromNamespaceAndPath(MyModMaybeIgMod.MODID, "sun"));

	public static void load() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_MOON,
				FabricItemGroup.builder().title(Component.translatable("item_group.my_mod_maybe_ig.moon")).icon(() -> new ItemStack(MyModMaybeIgModItems.MOONSTONE)).displayItems((parameters, tabData) -> {
					tabData.accept(MyModMaybeIgModBlocks.MOONSTONEORE.asItem());
					tabData.accept(MyModMaybeIgModItems.RAWMOONSTONE);
					tabData.accept(MyModMaybeIgModItems.MOONSTONEUPGRADETEMPLATE);
					tabData.accept(MyModMaybeIgModItems.MOONSTONE);
					tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_HELMET);
					tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_CHESTPLATE);
					tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_LEGGINGS);
					tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_BOOTS);
					tabData.accept(MyModMaybeIgModItems.MOONSTONEPICKAXE);
					tabData.accept(MyModMaybeIgModItems.MOONSTONEAXE);
					tabData.accept(MyModMaybeIgModItems.MOONSTONESHOVEL);
					tabData.accept(MyModMaybeIgModItems.MOONSTONESWORD);
					tabData.accept(MyModMaybeIgModItems.MOONSTONEHOE);
					tabData.accept(MyModMaybeIgModBlocks.MOONSTONEBLOCK.asItem());
				}).build());
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_SUN,
				FabricItemGroup.builder().title(Component.translatable("item_group.my_mod_maybe_ig.sun")).icon(() -> new ItemStack(MyModMaybeIgModItems.SUNSTONEINGOT)).displayItems((parameters, tabData) -> {
					tabData.accept(MyModMaybeIgModItems.RAWSUNSTONE);
					tabData.accept(MyModMaybeIgModItems.SUNSTONEINGOT);
					tabData.accept(MyModMaybeIgModItems.SUNSTONEUPGRADETEMPLATE);
					tabData.accept(MyModMaybeIgModItems.SUNSTONEPICKAXE);
					tabData.accept(MyModMaybeIgModItems.SUNSTONEAXE);
					tabData.accept(MyModMaybeIgModItems.SUNSTONESHOVEL);
					tabData.accept(MyModMaybeIgModItems.SUNSTONEHOE);
					tabData.accept(MyModMaybeIgModItems.SUNSTONESWORD);
					tabData.accept(MyModMaybeIgModBlocks.SUNBLOCK.asItem());
					tabData.accept(MyModMaybeIgModItems.SUNWATER_BUCKET);
					tabData.accept(MyModMaybeIgModBlocks.SUNSTONEORE.asItem());
				}).build());
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(tabData -> {
			tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_HELMET);
			tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_CHESTPLATE);
			tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_LEGGINGS);
			tabData.accept(MyModMaybeIgModItems.MOONSTONEARMOR_BOOTS);
			tabData.accept(MyModMaybeIgModItems.SUNSTONEARMOR_HELMET);
			tabData.accept(MyModMaybeIgModItems.SUNSTONEARMOR_CHESTPLATE);
			tabData.accept(MyModMaybeIgModItems.SUNSTONEARMOR_LEGGINGS);
			tabData.accept(MyModMaybeIgModItems.SUNSTONEARMOR_BOOTS);
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(tabData -> {
			tabData.accept(MyModMaybeIgModItems.MOONSTONEPICKAXE);
			tabData.accept(MyModMaybeIgModItems.MOONSTONEAXE);
			tabData.accept(MyModMaybeIgModItems.MOONSTONESHOVEL);
			tabData.accept(MyModMaybeIgModItems.MOONSTONESWORD);
			tabData.accept(MyModMaybeIgModItems.MOONSTONEHOE);
			tabData.accept(MyModMaybeIgModItems.SUNSTONEPICKAXE);
			tabData.accept(MyModMaybeIgModItems.SUNSTONEAXE);
			tabData.accept(MyModMaybeIgModItems.SUNSTONESHOVEL);
			tabData.accept(MyModMaybeIgModItems.SUNSTONEHOE);
			tabData.accept(MyModMaybeIgModItems.SUNSTONESWORD);
			tabData.accept(MyModMaybeIgModItems.SUNDIMENSION);
		});
	}
}