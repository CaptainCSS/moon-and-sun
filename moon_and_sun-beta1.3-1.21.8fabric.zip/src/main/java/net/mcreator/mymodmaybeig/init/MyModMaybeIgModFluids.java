/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymodmaybeig.init;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.mcreator.mymodmaybeig.fluid.SunwaterFluid;
import net.mcreator.mymodmaybeig.MyModMaybeIgMod;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.function.Supplier;

public class MyModMaybeIgModFluids {
	public static FlowingFluid SUNWATER;
	public static FlowingFluid FLOWING_SUNWATER;

	public static void load() {
		SUNWATER = register("sunwater", SunwaterFluid.Source::new);
		FLOWING_SUNWATER = register("flowing_sunwater", SunwaterFluid.Flowing::new);
	}

	@Environment(EnvType.CLIENT)
	public static void clientLoad() {
		SunwaterFluid.clientLoad();
	}

	private static <F extends Fluid> F register(String registryname, Supplier<F> element) {
		return (F) Registry.register(BuiltInRegistries.FLUID, ResourceLocation.fromNamespaceAndPath(MyModMaybeIgMod.MODID, registryname), element.get());
	}
}