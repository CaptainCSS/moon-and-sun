/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymodmaybeig.init;

import net.mcreator.mymodmaybeig.world.teleporter.SundimensionTeleporter;
import net.mcreator.mymodmaybeig.world.dimension.SundimensionDimension;

public class MyModMaybeIgModDimensions {
	public static void load() {
		SundimensionDimension.load();
		SundimensionTeleporter.registerPointOfInterest();
	}
}