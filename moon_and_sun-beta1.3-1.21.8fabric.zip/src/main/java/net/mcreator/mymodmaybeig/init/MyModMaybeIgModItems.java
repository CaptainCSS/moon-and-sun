/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymodmaybeig.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.mymodmaybeig.item.*;
import net.mcreator.mymodmaybeig.MyModMaybeIgMod;

import java.util.function.Function;

public class MyModMaybeIgModItems {
	public static Item MOONSTONEORE;
	public static Item RAWMOONSTONE;
	public static Item RAWSUNSTONE;
	public static Item SUNSTONEINGOT;
	public static Item MOONSTONEUPGRADETEMPLATE;
	public static Item SUNSTONEUPGRADETEMPLATE;
	public static Item MOONSTONE;
	public static Item MOONSTONEARMOR_HELMET;
	public static Item MOONSTONEARMOR_CHESTPLATE;
	public static Item MOONSTONEARMOR_LEGGINGS;
	public static Item MOONSTONEARMOR_BOOTS;
	public static Item MOONSTONEPICKAXE;
	public static Item MOONSTONEAXE;
	public static Item MOONSTONESHOVEL;
	public static Item MOONSTONESWORD;
	public static Item MOONSTONEHOE;
	public static Item SUNSTONEPICKAXE;
	public static Item SUNSTONEAXE;
	public static Item SUNSTONESHOVEL;
	public static Item SUNSTONEHOE;
	public static Item SUNSTONESWORD;
	public static Item SUNSTONEARMOR_HELMET;
	public static Item SUNSTONEARMOR_CHESTPLATE;
	public static Item SUNSTONEARMOR_LEGGINGS;
	public static Item SUNSTONEARMOR_BOOTS;
	public static Item MOONSTONEBLOCK;
	public static Item SUNBLOCK;
	public static Item SUNWATER_BUCKET;
	public static Item SUNDIMENSION;
	public static Item SUNSTONEORE;

	public static void load() {
		MOONSTONEORE = block(MyModMaybeIgModBlocks.MOONSTONEORE, "moonstoneore");
		RAWMOONSTONE = register("rawmoonstone", RawmoonstoneItem::new);
		RAWSUNSTONE = register("rawsunstone", RawsunstoneItem::new);
		SUNSTONEINGOT = register("sunstoneingot", SunstoneingotItem::new);
		MOONSTONEUPGRADETEMPLATE = register("moonstoneupgradetemplate", MoonstoneupgradetemplateItem::new);
		SUNSTONEUPGRADETEMPLATE = register("sunstoneupgradetemplate", SunstoneupgradetemplateItem::new);
		MOONSTONE = register("moonstone", MoonstoneItem::new);
		MOONSTONEARMOR_HELMET = register("moonstonearmor_helmet", MoonstonearmorItem.Helmet::new);
		MOONSTONEARMOR_CHESTPLATE = register("moonstonearmor_chestplate", MoonstonearmorItem.Chestplate::new);
		MOONSTONEARMOR_LEGGINGS = register("moonstonearmor_leggings", MoonstonearmorItem.Leggings::new);
		MOONSTONEARMOR_BOOTS = register("moonstonearmor_boots", MoonstonearmorItem.Boots::new);
		MOONSTONEPICKAXE = register("moonstonepickaxe", MoonstonepickaxeItem::new);
		MOONSTONEAXE = register("moonstoneaxe", MoonstoneaxeItem::new);
		MOONSTONESHOVEL = register("moonstoneshovel", MoonstoneshovelItem::new);
		MOONSTONESWORD = register("moonstonesword", MoonstoneswordItem::new);
		MOONSTONEHOE = register("moonstonehoe", MoonstonehoeItem::new);
		SUNSTONEPICKAXE = register("sunstonepickaxe", SunstonepickaxeItem::new);
		SUNSTONEAXE = register("sunstoneaxe", SunstoneaxeItem::new);
		SUNSTONESHOVEL = register("sunstoneshovel", SunstoneshovelItem::new);
		SUNSTONEHOE = register("sunstonehoe", SunstonehoeItem::new);
		SUNSTONESWORD = register("sunstonesword", SunstoneswordItem::new);
		SUNSTONEARMOR_HELMET = register("sunstonearmor_helmet", SunstonearmorItem.Helmet::new);
		SUNSTONEARMOR_CHESTPLATE = register("sunstonearmor_chestplate", SunstonearmorItem.Chestplate::new);
		SUNSTONEARMOR_LEGGINGS = register("sunstonearmor_leggings", SunstonearmorItem.Leggings::new);
		SUNSTONEARMOR_BOOTS = register("sunstonearmor_boots", SunstonearmorItem.Boots::new);
		MOONSTONEBLOCK = block(MyModMaybeIgModBlocks.MOONSTONEBLOCK, "moonstoneblock");
		SUNBLOCK = block(MyModMaybeIgModBlocks.SUNBLOCK, "sunblock", new Item.Properties().fireResistant());
		SUNWATER_BUCKET = register("sunwater_bucket", SunwaterItem::new);
		SUNDIMENSION = register("sundimension", SundimensionItem::new);
		SUNSTONEORE = block(MyModMaybeIgModBlocks.SUNSTONEORE, "sunstoneore", new Item.Properties().fireResistant());
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> I register(String name, Function<Item.Properties, ? extends I> supplier) {
		return (I) Items.registerItem(ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(MyModMaybeIgMod.MODID, name)), (Function<Item.Properties, Item>) supplier);
	}

	private static Item block(Block block, String name) {
		return block(block, name, new Item.Properties());
	}

	private static Item block(Block block, String name, Item.Properties properties) {
		return Items.registerItem(ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(MyModMaybeIgMod.MODID, name)), prop -> new BlockItem(block, prop), properties);
	}
}