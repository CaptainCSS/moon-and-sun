/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mymodmaybeig.init;

import net.mcreator.mymodmaybeig.fluid.SunwaterFluid;
import net.mcreator.mymodmaybeig.block.SundimensionPortalBlock;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class MyModMaybeIgModBlocksRenderers {
	public static void clientLoad() {
		SunwaterFluid.registerRenderLayer();
		SundimensionPortalBlock.registerRenderLayer();
	}
	// Start of user code block custom block renderers
	// End of user code block custom block renderers
}