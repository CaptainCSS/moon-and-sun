package net.mcreator.mymodmaybeig.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class SunstoneingotItem extends Item {
	public SunstoneingotItem(Item.Properties properties) {
		super(properties);
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}