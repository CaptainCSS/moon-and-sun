package net.mcreator.mymodmaybeig.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class SunstoneaxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 20310, 90f, 0, 2, TagKey.create(Registries.ITEM, ResourceLocation.parse("my_mod_maybe_ig:sunstoneaxe_repair_items")));

	public SunstoneaxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 99f, 6f, properties.fireResistant());
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}