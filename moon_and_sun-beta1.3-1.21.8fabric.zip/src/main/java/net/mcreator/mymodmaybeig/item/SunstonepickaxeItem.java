package net.mcreator.mymodmaybeig.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class SunstonepickaxeItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 20310, 90f, 0, 150, TagKey.create(Registries.ITEM, ResourceLocation.parse("my_mod_maybe_ig:sunstonepickaxe_repair_items")));

	public SunstonepickaxeItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 59f, 8f).fireResistant());
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}