package net.mcreator.mymodmaybeig.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class MoonstoneshovelItem extends ShovelItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 6093, 27f, 0, 45, TagKey.create(Registries.ITEM, ResourceLocation.parse("my_mod_maybe_ig:moonstoneshovel_repair_items")));

	public MoonstoneshovelItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 8.75f, -1f, properties.fireResistant());
	}
}