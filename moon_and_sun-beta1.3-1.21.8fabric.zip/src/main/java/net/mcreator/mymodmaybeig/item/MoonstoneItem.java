package net.mcreator.mymodmaybeig.item;

import net.minecraft.world.item.Item;

public class MoonstoneItem extends Item {
	public MoonstoneItem(Item.Properties properties) {
		super(properties);
	}
}