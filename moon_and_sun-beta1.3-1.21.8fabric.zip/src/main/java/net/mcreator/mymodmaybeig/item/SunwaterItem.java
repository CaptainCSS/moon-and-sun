package net.mcreator.mymodmaybeig.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.mymodmaybeig.init.MyModMaybeIgModFluids;

public class SunwaterItem extends BucketItem {
	public SunwaterItem(Item.Properties properties) {
		super(MyModMaybeIgModFluids.SUNWATER, properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}