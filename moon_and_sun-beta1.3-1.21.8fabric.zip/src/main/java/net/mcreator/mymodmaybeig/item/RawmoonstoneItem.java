package net.mcreator.mymodmaybeig.item;

import net.minecraft.world.item.Item;

public class RawmoonstoneItem extends Item {
	public RawmoonstoneItem(Item.Properties properties) {
		super(properties);
	}
}