package net.mcreator.mymodmaybeig.block;

import org.slf4j.Logger;

import org.jetbrains.annotations.Nullable;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Portal;
import net.minecraft.world.level.block.NetherPortalBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.BlockUtil;

import net.mcreator.mymodmaybeig.world.teleporter.SundimensionTeleporter;
import net.mcreator.mymodmaybeig.world.teleporter.SundimensionPortalShape;
import net.mcreator.mymodmaybeig.init.MyModMaybeIgModBlocks;

import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.Optional;

import com.mojang.logging.LogUtils;

public class SundimensionPortalBlock extends NetherPortalBlock {
	private static final Logger LOGGER = LogUtils.getLogger();

	public static void portalSpawn(Level world, BlockPos pos) {
		Optional<SundimensionPortalShape> optional = SundimensionPortalShape.findEmptyPortalShape(world, pos, Direction.Axis.X);
		if (optional.isPresent()) {
			optional.get().createPortalBlocks(world);
		}
	}

	public SundimensionPortalBlock(BlockBehaviour.Properties properties) {
		super(properties.noCollission().randomTicks().pushReaction(PushReaction.BLOCK).strength(-1.0F).sound(SoundType.GLASS).lightLevel(s -> 15).noLootTable());
	}

	private SundimensionTeleporter getTeleporter(ServerLevel level) {
		return new SundimensionTeleporter(level);
	}

	@Override
	protected BlockState updateShape(BlockState blockState, LevelReader levelReader, ScheduledTickAccess scheduledTickAccess, BlockPos blockPos, Direction direction, BlockPos blockPos2, BlockState blockState2, RandomSource randomSource) {
		boolean bl;
		Direction.Axis axis = direction.getAxis();
		Direction.Axis axis2 = blockState.getValue(AXIS);
		boolean bl2 = bl = axis2 != axis && axis.isHorizontal();
		if (bl || blockState2.is(this) || SundimensionPortalShape.findAnyShape(levelReader, blockPos, axis2).isComplete()) {
			return super.updateShape(blockState, levelReader, scheduledTickAccess, blockPos, direction, blockPos2, blockState2, randomSource);
		}
		return Blocks.AIR.defaultBlockState();
	}

	@Override
	@Nullable
	public TeleportTransition getPortalDestination(ServerLevel serverLevel, Entity entity, BlockPos blockPos) {
		ResourceKey<Level> resourceKey = serverLevel.dimension() == ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse("my_mod_maybe_ig:sundimension"))
				? Level.OVERWORLD
				: ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse("my_mod_maybe_ig:sundimension"));
		ServerLevel serverLevel2 = serverLevel.getServer().getLevel(resourceKey);
		if (serverLevel2 == null) {
			return null;
		}
		boolean bl = serverLevel2.dimension() == ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse("my_mod_maybe_ig:sundimension"));
		WorldBorder worldBorder = serverLevel2.getWorldBorder();
		double d = DimensionType.getTeleportationScale(serverLevel.dimensionType(), serverLevel2.dimensionType());
		BlockPos blockPos2 = worldBorder.clampToBounds(entity.getX() * d, entity.getY(), entity.getZ() * d);
		return this.getExitPortal(serverLevel2, entity, blockPos, blockPos2, bl, worldBorder);
	}

	@Nullable
	private TeleportTransition getExitPortal(ServerLevel serverLevel, Entity entity2, BlockPos blockPos2, BlockPos blockPos22, boolean bl, WorldBorder worldBorder) {
		TeleportTransition.PostTeleportTransition postTeleportTransition;
		BlockUtil.FoundRectangle foundRectangle;
		Optional<BlockPos> optional = getTeleporter(serverLevel).findClosestPortalPosition(blockPos22, bl, worldBorder);
		if (optional.isPresent()) {
			BlockPos blockPos3 = optional.get();
			BlockState blockState = serverLevel.getBlockState(blockPos3);
			foundRectangle = BlockUtil.getLargestRectangleAround(blockPos3, blockState.getValue(BlockStateProperties.HORIZONTAL_AXIS), 21, Direction.Axis.Y, 21, blockPos -> serverLevel.getBlockState((BlockPos) blockPos) == blockState);
			postTeleportTransition = TeleportTransition.PLAY_PORTAL_SOUND.then(entity -> entity.placePortalTicket(blockPos3));
		} else {
			Direction.Axis axis = entity2.level().getBlockState(blockPos2).getOptionalValue(AXIS).orElse(Direction.Axis.X);
			Optional<BlockUtil.FoundRectangle> optional2 = getTeleporter(serverLevel).createPortal(blockPos22, axis);
			if (optional2.isEmpty()) {
				LOGGER.error("Unable to create a portal, likely target out of worldborder");
				return null;
			}
			foundRectangle = optional2.get();
			postTeleportTransition = TeleportTransition.PLAY_PORTAL_SOUND.then(TeleportTransition.PLACE_PORTAL_TICKET);
		}
		return getDimensionTransitionFromExit(entity2, blockPos2, foundRectangle, serverLevel, postTeleportTransition);
	}

	private static TeleportTransition getDimensionTransitionFromExit(Entity entity, BlockPos blockPos2, BlockUtil.FoundRectangle foundRectangle, ServerLevel serverLevel, TeleportTransition.PostTeleportTransition postTeleportTransition) {
		Vec3 vec3;
		Direction.Axis axis;
		BlockState blockState = entity.level().getBlockState(blockPos2);
		if (blockState.hasProperty(BlockStateProperties.HORIZONTAL_AXIS)) {
			axis = blockState.getValue(BlockStateProperties.HORIZONTAL_AXIS);
			BlockUtil.FoundRectangle foundRectangle2 = BlockUtil.getLargestRectangleAround(blockPos2, axis, 21, Direction.Axis.Y, 21, blockPos -> entity.level().getBlockState((BlockPos) blockPos) == blockState);
			vec3 = entity.getRelativePortalPosition(axis, foundRectangle2);
		} else {
			axis = Direction.Axis.X;
			vec3 = new Vec3(0.5, 0.0, 0.0);
		}
		return createDimensionTransition(serverLevel, foundRectangle, axis, vec3, entity, postTeleportTransition);
	}

	private static TeleportTransition createDimensionTransition(ServerLevel serverLevel, BlockUtil.FoundRectangle foundRectangle, Direction.Axis axis, Vec3 vec3, Entity entity, TeleportTransition.PostTeleportTransition postTeleportTransition) {
		BlockPos blockPos = foundRectangle.minCorner;
		BlockState blockState = serverLevel.getBlockState(blockPos);
		Direction.Axis axis2 = blockState.getOptionalValue(BlockStateProperties.HORIZONTAL_AXIS).orElse(Direction.Axis.X);
		double d = foundRectangle.axis1Size;
		double e = foundRectangle.axis2Size;
		EntityDimensions entityDimensions = entity.getDimensions(entity.getPose());
		int i = axis == axis2 ? 0 : 90;
		double f = (double) entityDimensions.width() / 2.0 + (d - (double) entityDimensions.width()) * vec3.x();
		double g = (e - (double) entityDimensions.height()) * vec3.y();
		double h = 0.5 + vec3.z();
		boolean bl = axis2 == Direction.Axis.X;
		Vec3 vec32 = new Vec3((double) blockPos.getX() + (bl ? f : h), (double) blockPos.getY() + g, (double) blockPos.getZ() + (bl ? h : f));
		Vec3 vec33 = SundimensionPortalShape.findCollisionFreePosition(vec32, serverLevel, entity, entityDimensions);
		return new TeleportTransition(serverLevel, vec33, Vec3.ZERO, i, 0.0f, Relative.union(Relative.DELTA, Relative.ROTATION), postTeleportTransition);
	}

	@Override
	public int getPortalTransitionTime(ServerLevel world, Entity entity) {
		return 0;
	}

	@Override
	public Portal.Transition getLocalTransition() {
		return Portal.Transition.NONE;
	}

	@Override
	public void randomTick(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
	}

	@Override
	public void animateTick(BlockState state, Level world, BlockPos pos, RandomSource random) {
		for (int i = 0; i < 4; i++) {
			double px = pos.getX() + random.nextFloat();
			double py = pos.getY() + random.nextFloat();
			double pz = pos.getZ() + random.nextFloat();
			double vx = (random.nextFloat() - 0.5) / 2.;
			double vy = (random.nextFloat() - 0.5) / 2.;
			double vz = (random.nextFloat() - 0.5) / 2.;
			int j = random.nextInt(4) - 1;
			if (world.getBlockState(pos.west()).getBlock() != this && world.getBlockState(pos.east()).getBlock() != this) {
				px = pos.getX() + 0.5 + 0.25 * j;
				vx = random.nextFloat() * 2 * j;
			} else {
				pz = pos.getZ() + 0.5 + 0.25 * j;
				vz = random.nextFloat() * 2 * j;
			}
			world.addParticle(ParticleTypes.PORTAL, px, py, pz, vx, vy, vz);
		}
		if (random.nextInt(110) == 0)
			world.playLocalSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.portal.ambient")), SoundSource.BLOCKS, 0.5f, random.nextFloat() * 0.4f + 0.8f, false);
	}

	@Environment(EnvType.CLIENT)
	public static void registerRenderLayer() {
		BlockRenderLayerMap.putBlock(MyModMaybeIgModBlocks.SUNDIMENSION_PORTAL, ChunkSectionLayer.TRANSLUCENT);
	}
}