package net.mcreator.mymodmaybeig.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class SunblockBlock extends Block {
	public SunblockBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(45f, 100f).lightLevel(s -> 15).requiresCorrectToolForDrops());
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}