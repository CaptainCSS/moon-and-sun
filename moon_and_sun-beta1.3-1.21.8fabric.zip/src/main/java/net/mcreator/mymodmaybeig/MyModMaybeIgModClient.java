package net.mcreator.mymodmaybeig;

import net.mcreator.mymodmaybeig.init.MyModMaybeIgModFluids;
import net.mcreator.mymodmaybeig.init.MyModMaybeIgModBlocksRenderers;
import net.mcreator.mymodmaybeig.init.MyModMaybeIgModArmorModels;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ClientModInitializer;

@Environment(EnvType.CLIENT)
public class MyModMaybeIgModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Start of user code block mod constructor
		// End of user code block mod constructor
		MyModMaybeIgModBlocksRenderers.clientLoad();
		MyModMaybeIgModArmorModels.clientLoad();
		MyModMaybeIgModFluids.clientLoad();
		// Start of user code block mod init
		// End of user code block mod init
	}
	// Start of user code block mod methods
	// End of user code block mod methods
}